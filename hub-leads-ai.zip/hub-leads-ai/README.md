# Hub Leads AI (Hub Company) — fase 1

## Rodar
1. `cp .env.example .env.local` e preencha as chaves do Supabase (e `ANTHROPIC_API_KEY` para a análise).
2. Aplique `supabase/migrations/0001_core.sql` no projeto Supabase (SQL editor ou `supabase db push`).
3. `npm install && npm run dev`

## Implementado
- Migration com RLS (profiles, leads, lead_analyses, activities, usage_records), gatilho de perfil, origem dos dados e flag de não contato.
- `GET/POST /api/leads`: autenticação, validação Zod, limite de plano no servidor, aviso de possível duplicidade.
- `POST /api/analyze`: análise por IA (Claude) separando verificado / inferência / desconhecido, com limite mensal contado no servidor.
- Limites centralizados em `src/lib/plans.ts`.

## Pendente (não simulado)
Telas (login, dashboard, CRM, Kanban), busca de empresas (provedor não escolhido), geração de mensagens, listas, campanhas, tarefas, catálogo de serviços, billing/webhooks, CSV, LGPD (exportar/excluir dados, políticas), rate limiting, testes, seed.

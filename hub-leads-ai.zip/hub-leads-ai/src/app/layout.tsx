export const metadata = { title: "Hub Leads AI" };
export default function Root({ children }: { children: React.ReactNode }) {
  return <html lang="pt-BR"><body style={{ margin: 0, background: "#0b1624", color: "#e6edf5", fontFamily: "system-ui, sans-serif" }}>{children}</body></html>;
}

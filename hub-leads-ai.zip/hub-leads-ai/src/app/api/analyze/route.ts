import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseForRequest, supabaseAdmin } from "@/lib/supabase";
import { PLANS, PlanId } from "@/lib/plans";

const Body = z.object({ leadId: z.string().uuid() });
const SYSTEM = `Você analisa oportunidades comerciais para a Hub Company usando SOMENTE os dados fornecidos.
Responda em JSON com: resumo, necessidades_digitais[], oportunidades[], servico_recomendado, justificativa,
prioridade ("baixa"|"media"|"alta"), confianca ("baixa"|"media"|"alta"),
verificado[] (fatos presentes nos dados), inferencias[] (suposições, rotuladas como tais),
desconhecido[] (o que falta verificar), proxima_acao.
Nunca trate suposição como fato. Não invente dados, preços ou problemas não confirmados.`;

export async function POST(req: Request) {
  if (!process.env.ANTHROPIC_API_KEY)
    return NextResponse.json({ error: "Integração de IA não configurada (ANTHROPIC_API_KEY)." }, { status: 503 });
  const sb = supabaseForRequest();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return NextResponse.json({ error: "Não autenticado" }, { status: 401 });
  const body = Body.safeParse(await req.json().catch(() => null));
  if (!body.success) return NextResponse.json({ error: "Dados inválidos" }, { status: 400 });

  const { data: lead } = await sb.from("leads").select("*").eq("id", body.data.leadId).single(); // RLS garante posse
  if (!lead) return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 });

  const { data: profile } = await sb.from("profiles").select("plan").eq("id", user.id).single();
  const period = new Date().toISOString().slice(0, 7);
  const { count } = await sb.from("usage_records").select("id", { count: "exact", head: true })
    .eq("kind", "ai_analysis").eq("period", period);
  if ((count ?? 0) >= PLANS[(profile?.plan ?? "free") as PlanId].aiAnalysesPerMonth)
    return NextResponse.json({ error: "Limite mensal de análises atingido" }, { status: 402 });

  const facts = { nome: lead.name, categoria: lead.category, cidade: lead.city, estado: lead.state,
    site: lead.website, telefone: lead.phone ? "informado" : null, fonte: lead.source };
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL ?? "claude-sonnet-4-5", max_tokens: 1200, system: SYSTEM,
      messages: [{ role: "user", content: JSON.stringify(facts) }] }),
  });
  if (!r.ok) return NextResponse.json({ error: "O provedor de IA falhou. Tente novamente." }, { status: 502 });
  const text: string = (await r.json()).content?.[0]?.text ?? "";
  let result: unknown;
  try { result = JSON.parse(text.replace(/```json|```/g, "").trim()); }
  catch { return NextResponse.json({ error: "Resposta da IA em formato inesperado" }, { status: 502 }); }

  const admin = supabaseAdmin();
  await admin.from("usage_records").insert({ user_id: user.id, kind: "ai_analysis", period });
  const { data: saved } = await sb.from("lead_analyses").insert({ lead_id: lead.id, user_id: user.id, result }).select().single();
  return NextResponse.json({ analysis: saved }, { status: 201 });
}

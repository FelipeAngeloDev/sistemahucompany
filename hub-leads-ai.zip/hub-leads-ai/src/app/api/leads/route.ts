import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseForRequest } from "@/lib/supabase";
import { PLANS, PlanId } from "@/lib/plans";

const LeadInput = z.object({
  name: z.string().trim().min(1).max(200),
  category: z.string().max(100).optional(), city: z.string().max(100).optional(),
  state: z.string().length(2).optional(), website: z.string().url().optional(),
  phone: z.string().max(30).optional(), email: z.string().email().optional(),
  source: z.string().max(100).default("manual"), notes: z.string().max(5000).optional(),
});

export async function GET() {
  const sb = supabaseForRequest();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return NextResponse.json({ error: "Não autenticado" }, { status: 401 });
  const { data, error } = await sb.from("leads").select("*").order("created_at", { ascending: false });
  if (error) return NextResponse.json({ error: "Falha ao listar leads" }, { status: 500 });
  return NextResponse.json({ leads: data });
}

export async function POST(req: Request) {
  const sb = supabaseForRequest();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return NextResponse.json({ error: "Não autenticado" }, { status: 401 });
  const parsed = LeadInput.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Dados inválidos", issues: parsed.error.flatten() }, { status: 400 });

  const { data: profile } = await sb.from("profiles").select("plan").eq("id", user.id).single();
  const limit = PLANS[(profile?.plan ?? "free") as PlanId].maxLeads;
  const { count } = await sb.from("leads").select("id", { count: "exact", head: true });
  if ((count ?? 0) >= limit) return NextResponse.json({ error: "Limite de leads do plano atingido" }, { status: 402 });

  // possível duplicidade: mesmo nome + cidade
  const { data: dup } = await sb.from("leads").select("id").ilike("name", parsed.data.name)
    .eq("city", parsed.data.city ?? "").limit(1);
  const { data, error } = await sb.from("leads").insert({ ...parsed.data, user_id: user.id }).select().single();
  if (error) return NextResponse.json({ error: "Falha ao salvar lead" }, { status: 500 });
  return NextResponse.json({ lead: data, possibleDuplicateOf: dup?.[0]?.id ?? null }, { status: 201 });
}

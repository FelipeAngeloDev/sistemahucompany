export default function Home() {
  return (
    <main style={{ maxWidth: 720, margin: "15vh auto", padding: 24 }}>
      <h1 style={{ fontSize: 40 }}>Hub Leads AI</h1>
      <p style={{ color: "#9fb3c8" }}>Encontre empresas, analise oportunidades e organize sua prospecção. Os dados e as análises vêm das integrações que você conectar.</p>
      <a href="/cadastro" style={{ background: "#22d3b6", color: "#04201b", padding: "12px 20px", borderRadius: 8, textDecoration: "none", fontWeight: 600 }}>Criar conta</a>
    </main>
  );
}

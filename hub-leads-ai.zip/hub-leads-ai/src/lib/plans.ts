// Limites centralizados. Altere aqui; nunca espalhe pelo código.
export const PLANS = {
  free:     { maxLeads: 50,    aiAnalysesPerMonth: 10,  csvExport: false },
  pro:      { maxLeads: 2000,  aiAnalysesPerMonth: 300, csvExport: true  },
  business: { maxLeads: 20000, aiAnalysesPerMonth: 2000, csvExport: true },
} as const;
export type PlanId = keyof typeof PLANS;

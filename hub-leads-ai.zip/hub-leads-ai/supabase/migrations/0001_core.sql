-- Hub Leads AI: esquema base (modelo por usuário; evolui para organizations depois)
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  full_name text, plan text not null default 'free' check (plan in ('free','pro','business')),
  created_at timestamptz not null default now()
);
create table leads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  name text not null check (length(name) between 1 and 200),
  category text, city text, state text, website text, phone text, email text,
  source text not null default 'manual',          -- origem dos dados (LGPD)
  status text not null default 'novo' check (status in
    ('novo','para_analisar','pronto_contato','contatado','em_negociacao','interessado','convertido','perdido')),
  priority text check (priority in ('baixa','media','alta')),
  recommended_service text, notes text, next_contact_at timestamptz,
  do_not_contact boolean not null default false,  -- pedido de não contato
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index leads_user_status_idx on leads(user_id, status);
create index leads_user_name_idx on leads(user_id, lower(name));
create table lead_analyses (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references leads on delete cascade,
  user_id uuid not null references auth.users on delete cascade,
  result jsonb not null, edited_by_user boolean not null default false,
  created_at timestamptz not null default now()
);
create table activities (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references leads on delete cascade,
  user_id uuid not null references auth.users on delete cascade,
  kind text not null, detail text, created_at timestamptz not null default now()
);
create table usage_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  kind text not null, period text not null,  -- ex.: '2026-10'
  created_at timestamptz not null default now()
);
create index usage_user_period_idx on usage_records(user_id, kind, period);

-- RLS: cada usuário acessa apenas as próprias linhas
alter table profiles enable row level security;
create policy profiles_own on profiles for all using (id = auth.uid()) with check (id = auth.uid());
do $$ declare t text; begin
  foreach t in array array['leads','lead_analyses','activities'] loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy %I on %I for all using (user_id = auth.uid()) with check (user_id = auth.uid())', t||'_own', t);
  end loop;
end $$;
alter table usage_records enable row level security;
create policy usage_read_own on usage_records for select using (user_id = auth.uid());  -- escrita só via service role

create or replace function touch_updated_at() returns trigger as $$
begin new.updated_at = now(); return new; end $$ language plpgsql;
create trigger leads_touch before update on leads for each row execute function touch_updated_at();

create or replace function handle_new_user() returns trigger as $$
begin insert into profiles(id, full_name) values (new.id, new.raw_user_meta_data->>'full_name'); return new; end $$
language plpgsql security definer set search_path = public;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();
